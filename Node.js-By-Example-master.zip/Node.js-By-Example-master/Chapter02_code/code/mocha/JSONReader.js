module.exports = {
	read: function() {
		// get JSON
		return {};
	}
}