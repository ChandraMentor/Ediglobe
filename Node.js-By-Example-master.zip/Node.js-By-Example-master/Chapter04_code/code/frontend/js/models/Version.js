var Base = require('./Base');
module.exports = Base.extend({
  data: {
    url: '/api/version'
  }
});