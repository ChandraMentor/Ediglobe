module.exports = Ractive.extend({
  template: require('../../tpl/navigation')
});