define(function () {
    return {
        request: function() { }
    }
});
