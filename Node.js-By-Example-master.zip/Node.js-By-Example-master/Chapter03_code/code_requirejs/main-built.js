define('modules/ajax',[],function () {
    return {
        request: function() { }
    }
});

define('modules/router',[],function () {
    return {
        request: function() { }
    }
});

require(['modules/ajax', 'modules/router'], function(ajax, router) {
  
});
define("main", function(){});

